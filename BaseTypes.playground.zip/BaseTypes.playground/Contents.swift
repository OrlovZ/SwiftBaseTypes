// Типы данных в SWIFT, операции, методы и базовые свойства при работе с
// различными типами данных

// Справочник страницы 5-16, 26
import UIKit
import Foundation

// Контейнерные типы данных
    

    // Кортеж (Tuple)
var myProgramStatus=(200, "In Work", true)                              //Объявление кортежа(неявное)
var floatStatus: (Float, String, Bool) = (200.2, "In Work", true)       //Объявление кортежа(явное)
var fullTuple:(                                                         //Полное явное объявление кортежа
 name: String,                                                          //с присвоением имен переменным кортежа
 age: Int,                                                              //var tuple1(name1:type1, name2:type2,...,nameN:typeN)=
 readyForNewWork: Bool) = ("Evgeny", 27, true)                          //(Значение1, Значение2,...,Значение N)
type(of: myProgramStatus) == type(of: floatStatus)                      //Типы подобны если все переменные одинаковых типов
let (statusCode, statusText, statusConnect) = myProgramStatus           //Объявление через присвоение
var (myName, myAge) = ("Evgeny", 27)                                    //Объявление через приcсвоение с записью в переменные
myName                                                                  //Проверка записи в переменную
var (statusCode1, _ , _) = myProgramStatus                              //Запись в переменную отдлельных частей кортежа
statusCode1 = myProgramStatus.0                                         //Запись в переменную через ссылку на переменную в кортеже
fullTuple.readyForNewWork                                               //Обращение к переменной в кортеже через имя переменной
myProgramStatus.2 = false                                               //Изменение переменной в кортеже через ссылку
(1,"alpha") < (2,"beta")                                                //Сравнение кортежей, проверяется попарною При получении                                                                           //результата следующие пары не проверяются(1<2)

    //Кортежи в функциях
func someFunc (id:Int) -> (firstName: String, lastName: String){        //Возвращаемое значение функции может быть кортежем
    let firstName, lastName:String                                      //Для удобства можно сразу объявить имена переменных
    switch id{                                                          //для дальнейшего использования
        case 1:
            firstName="Evgeny"
            lastName="Orlov"
        case 2:
            firstName="Nadezhda"
            lastName="Orlova"
        default:
            firstName=""
            lastName=""
    }
    return (firstName, lastName)
}
var myFullName = someFunc(id:1)
//Обратились к переменной через имя переменной  объявленной при объявлении функции
myFullName.lastName




// ДИАПАЗОНЫ (Range)
    // Полуоткрытый тип
        // Бинарная форма оператора
let rangeInt = 1..<5
let rangeString="a"..<"z"
        // Префиксная форма оператора
let oneSideRange = ..<5 //0, 1, 2, 3, 4
let collection = [1, 6, 76, 12, 51, 34]
var a = collection[oneSideRange]
// Закрытый тип
    //Бинарная форма оператора
let rangeInt2 = 1...5    //1, 2, 3, 4, 5
let rangeInt3:ClosedRange<Int> = 1...10 //явное объявление
var b = collection[rangeInt2]
    //Постфиксная форма оператора
let infRange = 2...
var c = collection[infRange]
    //Префиксная форма оператора
let myRange = ...4
var d = collection[myRange]

type(of: rangeInt)
type(of: rangeInt2)
type(of: infRange)
type(of: myRange)
    //Свойства и методы диапазонов
rangeInt.count              //кол-во элементов
rangeInt2.contains(3)       //определение наличия элемента
rangeInt.isEmpty            //проверка наличия элемнтов в принципе
rangeInt2.lowerBound        //левая граница
rangeInt2.upperBound        //правая граница
rangeInt2.min()             //минимальное значение
rangeInt2.max()             //максимальное значение
rangeInt.hashValue          //рассчет хэша, работает только с бинарными диапазонами
rangeInt3 == rangeInt2      //протокол сравнения Equatable



//МАССИВЫ (Array)
    //Создание массивов
var ar1 = Array(arrayLiteral: 1, 2, 3, 4)
let ar2 = Array(0...10)
var ar3 = Array(repeating: "Huray", count: 4)
var arrayOne: Array <Int> = [1, 2, 3, 4, 5, 6]  //явные формы
var arrayTwo:[Character] = ["a", "b", "c", "d"] //объявления массивов

    //Доступ к элементам массива через индекс элемента
arrayOne[0]
ar2[2...5]

    //Тип данных массивов
type(of: ar1)
type(of: arrayTwo)

    //пустой массив
let emptyArray: [String] = []
let anotherEmptyArray = [String] ()

    //многомерный массив        ?????START???????
var arrayOfArrays = [[1,2,3], [4,5,6], [7,8,9]]
arrayOfArrays = [[1,2,3], [4,5,6], [7,8,9]]
arrayOfArrays[2] // получаем вложенный массив [7, 8, 9]
arrayOfArrays[2][1] //получаем элемент вложенного массива 8
    
    //Операции, методы и базовые свойства  при работе с массивами
        //Слияние массивов
let charsOne = ["a", "b", "c"]
let charsTwo = ["d", "e", "f"]
let charsThree = ["g", "h", "i"]
var alphabet = charsOne + charsTwo
alphabet += charsThree
alphabet // ["a", "b", "c", "d", "e", "f", "g", "h", "i"]

        //Свойство count возвращает количество элементов в массиве
var someArray = [1, 2, 3, 4, 5]
someArray.count // 5
let emptyArray2: [Int] = []
emptyArray.count // 0

        //Свойство isEmpty проверяет на наличие элементов в массиве
emptyArray.isEmpty // true

        //Метод suffix(_:) - получение части массива, в кач-ве входного параметра кол-во элементов с конца массива
let someArray2 = someArray.suffix(3) // [3, 4, 5]

        //Свойства first и last возвращают первый и последний элементы массива
someArray.first // 1
someArray.last  // 5
        
        //C помощью метода append(_:) можно добавить новый элемент в конец массива
someArray // [1, 2, 3, 4, 5]
someArray.append(6) // [1, 2, 3, 4, 5, 6]

        //Если массив хранится в переменной (то есть является изменяемым),
        //то метод insert(_:at:) вставляет в массив новый одиночный элемент с указанным индексом
var numArray = [1, 2, 3, 4, 5, 6]
numArray.insert(100, at: 2) // [1, 2, 100, 3, 4, 5, 6]
    
        //методы remove(at:), removeFirst() и removeLast() позволяют удалять требуемые элементы.
        //При этом они возвращают значение удаляемого элемента
numArray // [1, 2, 100, 3, 4, 5, 6]  удаляем третий элемент массива (с индексом 2)
numArray.remove(at: 2) // 100  удаляем первый элемент массива
numArray.removeFirst() // 1  удаляем последний элемент массива
numArray.removeLast() // 6
/*итоговый массив содержит всего четыре элемента */
numArray // [2, 3, 4, 5] //После удаления индексы оставшихся элементов массива перестраиваются.

        //Для редактирования массива также можно использовать методы dropFirst(_:) и dropLast(_:),
        //возвращающие новый массив, в котором отсутствует несколько первых или последних элементов,
        //но при этом не изменяющие исходную коллекцию
numArray.dropLast() // [2, 3, 4] // удаляем последний элемент
let anotherNumArray = numArray.dropFirst(3) // удаляем три первых элемента
anotherNumArray // [5]
numArray // [2, 3, 4, 5]
        
        //Метод contains(_:) определяет факт наличия некоторого элемента в массиве и
        //возвращает Bool в зависимости от результата
let resultTrue = numArray.contains(4) // true
let resultFalse = numArray.contains(10) // false

        //Для поиска минимального или максимального элемента в массиве применяются методы min() и max().
        //Данные методы работают только в том случае, если элементы массива можно сравнить между собой
let randomArray = [3, 2, 4, 5, 6, 4, 7, 5, 6]
randomArray.min() // 2  // поиск минимального элемента
randomArray.max() // 7    // поиск максимального элемента
        
        //Чтобы изменить порядок следования всех элементов массива на противоположный, используйте метод reverse()
var myAlphaArray = ["a", "bb", "ccc"]
myAlphaArray.reverse()
myAlphaArray // ["ccc", "bb", "a"]
        
        //Методы sort() и sorted() позволяют отсортировать массив по возрастанию. Разница между ними состоит в том,
        //что sort() сортирует саму последовательность, для которой он вызван, а sorted(),
        //заменяя оригинальный массив, возвращает отсортированную коллекцию
// исходная неотсортированная коллекция
var unsortedArray = [3, 2, 5, 22, 8, 1, 29]
// метод sorted() возвращает отсортированную последовательность
// при этом исходный массив не изменяется
let sortedArray = unsortedArray.sorted()
unsortedArray // [3, 2, 5, 22, 8, 1, 29]
sortedArray // [1, 2, 3, 5, 8, 22, 29]
// метод sort() изменяет исходный массив
unsortedArray.sort()
unsortedArray // [1, 2, 3, 5, 8, 22, 29]
        
        //Метод randomElement() позволяет получить случайный элемент массива
let moneyArray = [50, 100, 500, 1000, 5000]
let randomMoneyElement = moneyArray.randomElement()

        //Метод enumerated() возвращает кортеж (индекс, значение) для одного элемента массива
for (index, itemFromArray) in unsortedArray.enumerated() {
    print ("\(index+1) элемент - \(itemFromArray)")
}

        //Срезы массивов
        /*При использовании некоторых из описанных ранее свойств и методов возвращается не массив,
        а значение некого типа данных ArraySlice. Это происходит, например, при получении части массива
        с помощью оператора диапазона или при использовании методов dropFirst() и dropLast()*/
    // исходный массив
let arrayOfNumbers = Array(1...10)
// его тип данных - Array<Int>
type(of: arrayOfNumbers) // Array<Int>.Type
arrayOfNumbers // [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
// получим часть массива (подмассив)
let slice = arrayOfNumbers[4...6]
slice // [5, 6, 7]
// его тип данных отличается от типа исходного массива
type(of: slice) // ArraySlice<Int>.Type
        /*Так же тип данных возвращаемого методами dropFirst() и dropLast() значения можно изменить,
        если явно указать тип данных параметра, которому инициализируется результат.
        Стоит обратить внимание на то, что индексы ArraySlice соответствуют индексам исходной коллекции,
        то есть они не обязательно начинаются с 0*/
let newArray: Array<Int> = arrayOfNumbers.dropLast()
type(of: newArray) // Array<UInt>.Type
// исходный массив
arrayOfNumbers // [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
// его срез, полученный в одном из предыдущих листингов
slice // [5, 6, 7]
// отдельный элемент
arrayOfNumbers[5] // 6
slice[5] // 6


//Множества (Set)
    //Объявление множеств
let mySet: Set <Int> = [1, 5, 0]
let mySet1: Set = [1, 5, 0]
let mySet2 = Set <Int> (arrayLiteral: 5,  6,  12)
let mySet3 = Set(arrayLiteral: 5, 66, 12)

    //пустые множества
let emptySet = Set <String>()
var setWithValues: Set<String> = ["Хлеб","Овощи"]
setWithValues = []                  //обнулили

    //Операции, методы и базовые свойства при работе с множествами
        //метод insert() создание нового эл-та, передается создаваемое значение соответствующее типу множества,
        //возвращается кортеж (результат, переменная)
var musicStylesSet: Set<String> = []
musicStylesSet.insert("Jazz")       //(inserted true, memberAfterInsert "Jazz"
musicStylesSet

        //методы remove() и removeAll() удаляют элемент(ы) с указанным значением и возвращает значение удаленного
        //элемента, либо nil при его отсутствии
musicStylesSet = ["Jazz", "Hip-Hop", "Rock"]
var removedStyle = musicStylesSet.remove("Hip-Hop")
musicStylesSet

        //метод contains и свойство count работают идентично работе с массивами
var doYouLoveRock = musicStylesSet.contains("Rock")
musicStylesSet.count

        //операция intersection(_:) возвращает множество, содержащее значения общие для множеств
let oddDigits:Set = [1,3,5,7,9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let difDigits: Set = [3, 4, 7, 8]
let inter = difDigits.intersection(oddDigits)
let inter2 = difDigits.intersection(evenDigits)

        //операция symmetricDifference(_:) возвращает множество с непересекающимися значениям
let exclusive = difDigits.symmetricDifference(oddDigits)
let exclusive2 = difDigits.symmetricDifference(evenDigits)

        //метод union(_:) объединяет множества в одно
let unionSet = evenDigits.union(oddDigits)
let anotherUnionSet = oddDigits.union(difDigits)
unionSet

        //метод subtracting(_:) возвращает множество с эл-ми 1 множества, которые не входят во второе
let subtract = difDigits.subtracting(evenDigits)
subtract

        //множества, подмножества и  надмножества
var aSet: Set = [1, 2, 3, 4, 5] //надмножество для cSet
var bSet: Set = [5, 6, 7, 8]    //пересекающееся с aSet
var cSet: Set = [1, 3]          //подмножество для aSet
var copyCSet = cSet
    
        //методы isSuperset(of:) b isSubset(of:) проверяют являются ли множество надмножеством для другого, или подмножеством
        //причем при эквивалентности тоже возвращает true
aSet.isSuperset(of: cSet)
cSet.isSubset(of: aSet)
cSet.isSuperset(of: copyCSet)
cSet.isSubset(of: copyCSet)

        //методы isStrictSubset(_:) isStrictSuperset(_:) идентичны предыдущим, кроме условия эквивалентности
aSet.isStrictSuperset(of: cSet)
cSet.isStrictSubset(of: aSet)
cSet.isStrictSuperset(of: copyCSet)
cSet.isStrictSubset(of: copyCSet)

        //метод isDisjoint(with:) проверяет налиичие пересекающихся элементов, при их отсутствии возвращает true
bSet.isDisjoint(with: cSet)
cSet.isDisjoint(with: difDigits)

        //метод sorted() сортирует множество, но возвращается массив, т.к. нет смысла сортировать множество
let setOfNumbers: Set = [1, 10, 2, 5, 12, 23]
let sortedArray1=setOfNumbers.sorted()
sortedArray1
type(of: sortedArray1)


    //Словари (Dictionary)
        //объявление
let dictOne: Dictionary <Int, String> = [200:"success", 300:"warning", 400:"error"]
let dictionary = ["one":"один", "two": "два", "three":"три"]
let nDict: [String:String] = ["John":"Dave","Mike":"Lax"]
var Dic = Dictionary(dictionaryLiteral: (100, "Сто"), (200, "Двести"), (300, "Триста"))
let baseCollection = [(2, 5), (3, 6), (1, 4)] // базовая коллекция кортежей (пар значений)
let newDictionary = Dictionary(uniqueKeysWithValues: baseCollection) // создание словаря на основе базовой коллекции
newDictionary // [3: 6, 2: 5, 1: 4]
let nearestStarNames = ["Proxima Centauri", "Alpha Centauri A",
"Alpha Centauri B"]
let nearestStarDistances = [4.24, 4.37, 4.37] // массив расстояний до звезд
let starDistanceDict = Dictionary(uniqueKeysWithValues: zip(nearestStarNames, nearestStarDistances)) // получение словаря, содержащего пары значений
starDistanceDict

        //Обновление элементов словаря:
            //метод updateValue(_:forKey:)
var countryDict = ["RUS":"Russia","BEL":"Belarus","UKR":"Ukraine"]
var countryName = countryDict["BEL"]
countryDict["RUS"] = "RF"
var oldValueOne = countryDict.updateValue("Republic Belarus", forKey: "BEL")  //в переменную записывается старое значение
var oldValueTwo = countryDict.updateValue("Estonia", forKey: "EST") //в словаре нет такого ключа, в переменную запишется nil

            //создание нового элемента
countryDict["TUR"] = "Turkey"
countryDict

            //удаление элементов
countryDict["TUR"] = nil //удаляет пару ключ:значение
countryDict.removeValue(forKey: "BEL")
countryDict
var deletedValue = countryDict.removeValue(forKey: "UKR") //в deletedValue записывается удаленное значение
countryDict = [:] //очистка всех элементов

            //Пустой словарь
let emptyDict: [String:Int] = [:]
let anotherEmptyDict = Dictionary<String,Int>()

        //Операции, методы и базовые свойства при работе со словарями
            //Свойства count и isEmpty работают идентично работе с массивами
countryDict.count
countryDict.isEmpty
emptyDict.isEmpty

            //Свойство keys возвращает все ключи в словаре. Возвращается специальный тип данных (коллекция). Легко переводится в массив или множество
let keys = countryDict.keys
type(of: keys)
var keysArray = Array(keys)
var keysSet = Set(keys)


            //Свойство values возвращает все значения в словаре. Возвращается специальный тип данных (коллекция). Легко переводится в массив или множество
let values = countryDict.values
type(of: values)
var valuesArray = Array(values)
var valuesSet = Set(values)



//Строка (String)
    //объявление символов и строк
let char: Character = "\u{E9}"
let anotherChar: Character = "\u{65}\u{301}"
char == anotherChar
let str = "Hello!"
var emptyStr: String = ""
var newStr: String = "Новая строковая переменная"

// посимвольное сравнение строк, те
// сравнивается первый символ из первой строки и первый из второй, если есть разница то это итог сравнения
// если символы одинаковые проверяется следующая пара симфолов
// Пример:
("alpha") < ("beta")
("aaaa") < ("aaab")
("aaaa") > ("b")

        //Строковые индексы (Ссылка на область памяти содержащая графем-кластер с записанным символом)
let name = "e\u{301}lastic" // "élastic"
let index = name.startIndex
let firstChar = name[index]
firstChar // "é"
type(of: firstChar)
type(of: index)

            //способы взаимодействия со строковыми индексами
name.count                      //количество символов
name.unicodeScalars.count        //количество юникод-скаляров
name.startIndex //Возвращает индекс первого элемента
name[name.startIndex]
let indexLastChar = name.endIndex //возвращает индекс последнего элемента
//name[indexLastChar] // Fatal error: String index is out of bounds т.к. на самом деле последний инедкс ссылается на ячейку памяти следующую после последнего символа
name[name.index(before: indexLastChar)]   //пример получния последнего символа строки. index(before:) возвращает предыдущий индекс
name[name.index(after: name.startIndex)]  //index(after:) возвращает следующий индекс
var fourCharacterIndex = name.index(name.startIndex, offsetBy: 3) //возвращает индекс символа с учетом отступа
name[fourCharacterIndex]

        //подстроки (Substring) (ссылка на область памяти содержащую String) (reference type)
let abc = "abcdefghijklmnopqrstuvwxyz"
let firstCharacterIndex = abc.startIndex
let fourCharIndex = abc.index(firstCharacterIndex, offsetBy: 3)
let subAbc = [firstCharacterIndex ... fourCharacterIndex]
type(of: subAbc)
let subStr = abc[fourCharacterIndex...]

